<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	//http://localhost/2020CodeAudit/C5/5-2-2-preg.php?a=b|${@phpinfo()}
	
	echo "动态函数执行防范举例："."</br>";
	
	// echo ${@phpinfo()};
	// $b=@phpinfo();
	
	preg_replace('/(\w+)\|(.*)/ie','$\\1 = "\\2";',$_GET['a']);
	
	// preg_replace('/(\w+)\|(\d+)/ie','$\\1 = "\\2";',$_GET['a']);
	
	// preg_replace('/(\w+)\|(.*)/ie','$\\1 = \'\\2\';',$_GET['a']);//
?>