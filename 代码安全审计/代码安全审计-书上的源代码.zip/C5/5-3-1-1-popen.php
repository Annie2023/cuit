<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "popen()函数举例，输出重定向："."</br>";
	echo 'popen(' . 'whoami >> E:/2.txt' .','. '\'r\')';
	popen('whoami > E:/2.txt','r');
	
?>