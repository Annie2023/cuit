<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "array_map()函数举例："."</br>";
	function myfunction($v)
	{
		return($v*$v);
	}
	$a=array(1,2,3,4,5);
	print_r(array_map("myfunction",$a));
?>