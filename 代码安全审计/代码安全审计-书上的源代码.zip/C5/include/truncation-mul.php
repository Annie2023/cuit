<?php
	header("Content-Type: text/html; charset=utf-8");//使PHP显示中文
	$str = '';
	for($i=0;$i<=199;$i++){ //最小值为199.小于199不能截断
		$str .= '.';
		// $str .= './';
	}
	$str = '2.txt' . $str;
	echo $str . "<br />";
	include $str . '.php';//$str变量的值为2.txt................php
?>