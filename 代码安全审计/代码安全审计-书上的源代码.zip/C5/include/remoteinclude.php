<?php
	header("Content-Type: text/html; charset=utf-8");//使PHP显示中文
	include($_GET['url']);
?>