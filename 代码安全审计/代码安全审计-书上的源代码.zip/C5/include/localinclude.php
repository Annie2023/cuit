<?php
	header("Content-Type: text/html; charset=utf-8");//使PHP显示中文
	echo "本地文件包含示例：" . "<br />";
	define("ROOT",dirname(__FILE__)."\\");//ROOT的作用及内容？
	// echo ROOT . "<br />";
	//加载模块
	$mod = $_GET['mod'];
	echo ROOT . $mod . '.php';
	include(ROOT . $mod . '.php');
?>