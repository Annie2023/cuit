<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "escapeshellarg()函数举例："."</br>";
	echo 'ls ' . escapeshellarg('a".  ".    ');
	
?>