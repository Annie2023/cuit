<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "preg_replace()函数举例："."</br>";
	preg_replace("/\[(.*)\]/e",'\\1',$_GET['str']);
?>