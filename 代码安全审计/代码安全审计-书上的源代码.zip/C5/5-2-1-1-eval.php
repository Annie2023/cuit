<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "eval()和assert()函数举例："."</br>";
	$a = '123';
	$b = '456';
	$c = '789';
	eval('$a=$b;');//注意分号位置
	assert('$b=$c');//注意分号位置
	var_dump($a);
	echo "<br />";
	var_dump($b);
?>