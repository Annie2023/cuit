<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "system()函数举例，whoami的执行结果为："."</br>";
	system('whoami');
	
?>