<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "escapeshellcmd()函数举例："."</br>";
	echo (escapeshellcmd($_GET['cmd']));
	//cmd=whoami('")^$ipconfig
?>