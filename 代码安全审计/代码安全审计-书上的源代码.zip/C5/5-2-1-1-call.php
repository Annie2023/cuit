<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "call_user_func()函数举例："."</br>";
	$b = "phpinfo()";
	call_user_func($_GET['a'],$b);//
	//a=assert ,如果改成$_GET['A']？？
?>