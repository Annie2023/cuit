<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "``反引号执行举例："."</br>";
	echo `whoami`;
	
?>