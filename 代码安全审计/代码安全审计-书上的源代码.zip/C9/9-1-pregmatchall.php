<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "PHP中preg_match_all 函数举例："."<br />";

/*preg_match_all 函数：搜索 subject 中所有匹配 pattern 给定正则表达式的匹配结果并且将它们以 flag 指定顺序输出到 matches 中。
*/
    $html = "<div class='container'><h3>Hello, World!</h3></div>";
	echo '$html字符串内容为：'."<br />".htmlspecialchars($html)."<br />";
    // $pattern = "/<([^>]+)>[^<]*<\/\1>/";
	// $pattern = "/\<([^\<]+)\>/is";
	//$pattern = "/\<(.+?)\>/is";
	$pattern = "/\<(.*?)\>/is";
    preg_match_all($pattern, $html, $matches);
    // print_r($matches[0]);
	print_r($matches[1]);
?>