<?php
	$str = 'cfg_GLOBALSsss';
	//preg_match()返回 pattern 的匹配次数。 它的值将是 0 次（不匹配）或 1 次，因为 preg_match() 在第一次匹配后 将会停止搜索。
	$isMatched = preg_match('#^(cfg_|GLOBALS|_GET|_POST|_COOKIE)#', $str, $matches);
	var_dump($isMatched,$matches);
	
	/*
	// 从URL中获取主机名称
	
	preg_match('@^(?:http://)?([^/]+)@i',"http://www.runoob.com/index.html", $matches);
	$host = $matches[1];
	var_dump($matches);
	echo "<br />";
	// 获取主机名称的后面两部分
	preg_match('/[^.]+\.[^.]+$/', $host, $matches);
	echo "domain name is: {$matches[0]}\n";*/
?>