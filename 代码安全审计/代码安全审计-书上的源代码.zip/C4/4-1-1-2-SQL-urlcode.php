<?php
	$a = addslashes($_GET['p']);//p=1%2527
	$b = urldecode($a);//a=1%27
	echo '$a='.$a;
	echo '<br />';
	echo '$b='.$b;
?>