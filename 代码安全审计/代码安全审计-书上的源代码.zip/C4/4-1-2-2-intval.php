<?php
	$id = intval("12aaa3 union 7select456 ");
	
	echo $id;
?>