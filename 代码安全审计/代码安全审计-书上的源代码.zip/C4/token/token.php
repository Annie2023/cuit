<form action="token-do.php" method="POST">
	<?php $module=mt_rand(100000,999999);?>
	<input type="text" name="sec_name" value=""/>
	<input type="hidden" name="module" value="<?php echo $module;?>"/>
	<input type="hidden" name="timestamp" value="<?php echo time();?>"/>
	<input type="hidden" name="token" value="<?php echo md5($module.'#$@%!^*'.time());?>"/>
	<input type="submit"/>
</form>