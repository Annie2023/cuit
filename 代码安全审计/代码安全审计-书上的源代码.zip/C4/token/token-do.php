<?php
	header("Content-Type:text/html;charset=utf-8");
	$module = $_POST['module'];
	$timestamp = $_POST['timestamp'];
	$token = md5($module . '#$@%!^*' . $timestamp);
	echo "The token is::" . $token ."<br />";
	echo "POST token is::" . $_POST['token']."<br />";
	echo "POST time is::" . $_POST['timestamp']."<br />";
	if($token != $_POST['token']){
		echo("非法数据来源");
		exit();
	}
	$sec_name=$_POST['sec_name'];
	echo "POST sec_name is::" . $_POST['sec_name']."<br />";
?>