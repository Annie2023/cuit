<?php
	session_start();
	echo $_SESSION['token'] ."<br />";
	function set_token(){
		$_SESSION['token'] = md5(time()+rand(1,1000));
	}
	function check_token(){
		if(isset($_POST['token']) && $_POST['token'] === $_SESSION['token']){
			return true;
		}
		else{
			return false;
		}
	}
	if(isset($_SESSION['token']) && check_token()){
		echo "success";
	}
	else{
		echo "failed";
	}
	set_token();
?>
<form method="post">
	<input type="hidden" name="token" value="<?=$_SESSION['token']?>">
	<input type="submit"/>
</form>