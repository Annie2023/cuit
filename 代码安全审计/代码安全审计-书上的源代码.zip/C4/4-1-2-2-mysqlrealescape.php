<?php
	$conn = mysql_connect('localhost','root','root');
	$id = mysql_real_escape_string($_GET['id'],$conn);
	echo $id.'<br />';
	$sql = "SELECT * FROM userinfo where id='".$id."'";
	echo $sql;
?>