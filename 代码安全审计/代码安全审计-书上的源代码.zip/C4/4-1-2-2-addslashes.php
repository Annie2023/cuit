<?php
	$str = "phpsafe'";
	echo addslashes($str);
?>