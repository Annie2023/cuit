<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "parse_str()函数使用举例："."<br />";
	$a = array("b" => "55","k" => "66");
	var_dump($a);
	echo '<br />';
	$b = 1234;
	// parse_str('b=5678');//注意：()中的内容为字符串。= 不是赋值。
	parse_str("b=33",$a);//覆盖掉$a数组中的key为 b 的键值，其他键值对删除
	// parse_str('b=33&k=44&v=77',$a);//覆盖掉$a数组中的key为 b k 的键值，新建v=77。
	print_r($b);
    echo '<br />';
	var_dump($a);	
	
	
	
/*	$str = "first=value&arr[]=foo+bar&arr[]=baz";

 	// 推荐用法
	parse_str($str, $output);
	echo $output['first'];  // value
	echo $output['arr'][0]; // foo bar
	echo $output['arr'][1]; // baz

	// 不建议这么用
	parse_str($str);
	echo $first;  // value
	echo $arr[0]; // foo bar
	echo $arr[1]; // baz */
?>