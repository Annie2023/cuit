<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "is_numeric()函数绕过举例："."<br />";
	if(is_numeric($_GET['var'])){
		$sql = "insert into tables(1,2) values('xx',{$_GET['var']})";
		echo $sql;
	}	
	
?>