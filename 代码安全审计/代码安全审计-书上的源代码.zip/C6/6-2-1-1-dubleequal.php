<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "==和===举例："."<br />";
	var_dump($_GET['var']==2);//var=2abc
	echo "<br />";
	var_dump($_GET['var']===2);//var=2abc
	
?>