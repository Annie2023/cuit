<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "in_array()函数绕过举例："."<br />";
	// var_dump(in_array('b', array('a', 'b' , 'c')));
	if(in_array($_GET['typeid'],array(1,2,3,4))){
		$sql = "select * from users where typeid='" . $_GET['typeid'] ."'";
		echo $sql;
	}	
	
?>