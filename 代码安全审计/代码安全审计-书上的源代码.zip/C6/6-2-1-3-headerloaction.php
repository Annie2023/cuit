<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "header()函数跳转绕过举例："."<br />";
	if($_GET['var']==='aa'){
		//程序已安装，跳转到首页
		header("Location: ./1-register.php");
	}	
	echo $_GET['var'];
?>