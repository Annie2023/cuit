<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "import_request_variables()函数使用举例："."<br />";
	$b = 21234;
	import_request_variables('GPC');//?b=2
	echo "\$a = $a";
	echo '<br />';
	echo "\$b = $b";
	echo '<br />';
	echo "\$c = $c";
?>