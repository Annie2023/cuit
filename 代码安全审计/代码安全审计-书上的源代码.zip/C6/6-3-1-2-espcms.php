<?php
    header("Content-Type: text/html; charset=utf-8");//PHP
	// echo "ecshop的cookie"."<br />";
	//db_pscode是安装的时候随机生成的一个字符串常量，保存在配置文件里。
	//注意替换key
	function eccode($string, $operation='DECODE', $key='9a93bc40e53f31e10ff47d97bd93c4a2') 
	{
		$result = '';
		if ($operation == 'ENCODE') {
			for ($i = 0; $i < strlen($string); $i++) {
				$char = substr($string, $i, 1);
				$keychar = substr($key, ($i % strlen($key)) - 1, 1);
				$char = chr(ord($char) + ord($keychar));
				$result.=$char;
			}
			$result = base64_encode($result);
			$result = str_replace(array('+', '/', '='), array('-', '_', ''), $result);
		} elseif ($operation == 'DECODE') {
			$data = str_replace(array('-', '_'), array('+', '/'), $string);
			$mod4 = strlen($data) % 4;
			if ($mod4) {
				$data .= substr('====', $mod4);
			}
			$string = base64_decode($data);
			for ($i = 0; $i < strlen($string); $i++) {
				$char = substr($string, $i, 1);
				$keychar = substr($key, ($i % strlen($key)) - 1, 1);
				$char = chr(ord($char) - ord($keychar));
				$result.=$char;
			}
		}
		return $result;
	}
		
	// $a = 'Y7Xdaa-T366YxqOa2ZSfpaKhlMmjpM21aZOXaWqTapVlbN1pr5qbmJaXZmbImGeXlmGflpdoyJ2YmZpwmcRokpOakp5n3saYaZVqY8holMdnlZafZJiVbmjHx2qZlG2XlZ_HnGPF';
	// $a = 'zhangsan';
	// echo eccode($a,'DECODE');
	// $a = 'rKHCp5rVxKI';
	$a = '2||0|2|lisi@qq.comi|2130706433|0|88df213be62e190c1dda767fa41aa1e4|cd9050b5cb6e090a151ec1f196cffc0c';
	// $a = 'lisi';
	// echo eccode('zhangsan','ENCODE');
	
	echo eccode($a,'ENCODE');
	
	
	
?>