<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文  a=0&b=%00'
	echo "ecshop逻辑错误注入，举例："."<br />";
	$a = addslashes($_GET['a']);//  0
	$b = addslashes($_GET['b']);// b=%00'  \0\'
	print_r($a . '<br />');
	print_r($b . '<br />');
	print_r(str_replace($a,'',$b));//  \\'
?>