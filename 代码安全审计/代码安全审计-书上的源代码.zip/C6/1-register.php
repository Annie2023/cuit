<?php
	echo "register_Globals����"."</br>";
	if($user=='admin'){
		echo 'ture';
		//do something
	}
?>