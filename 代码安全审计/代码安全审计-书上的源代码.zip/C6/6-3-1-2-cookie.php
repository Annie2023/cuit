<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo '显示cookie内容：'."<br />";
	
	foreach(array('_COOKIE','_POST','_GET') as $_request){
		var_dump($$_request);
		exit();
		
	}
	// echo '$a的值为：'. $a . '<br />';
	// echo '$b的值为：'. $b . '<br />';
	// echo '$c的值为：'. $c . '<br />';
	
?>