<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo '$$变量覆盖函数使用举例：'."<br />";
	//注意：清空原_COOKIE。
	setcookie("_key", "", time() - 3600);
	setcookie("_value", "", time() - 3600);
	$a = x;
	$b = y;
	$c = z;
	foreach(array('_COOKIE','_POST','_GET') as $_REQUEST){
	// foreach(array('_GET','_COOKIE','_POST') as $_REQUEST){
		// var_dump($$_REQUEST);//$_COOKIE
		// exit();
		foreach($$_REQUEST as $_key => $_value){
			echo $_key . '<br />';
			// echo $_value . '<br />';
			$$_key = addslashes($_value);
		}
	}
	echo '$a的值为：'. $a . '<br />';
	echo '$b的值为：'. $b . '<br />';
	echo '$c的值为：'. $c . '<br />';
	
?>