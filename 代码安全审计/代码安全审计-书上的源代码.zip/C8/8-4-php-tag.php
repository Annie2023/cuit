<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PHP代码解析标签使用举例</title>
</head>
<body>
<!--<? phpinfo(); ?>-->
<!--<script language="php">phpinfo()</script>-->
<!--<% phpinfo(); %>-->

</body>
</html>
