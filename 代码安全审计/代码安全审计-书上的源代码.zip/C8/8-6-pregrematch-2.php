<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "不严谨的正则表达式，特殊字符".'.'."未转义："."<br />";
	
	$filename = urldecode('xxx.php%00jpg');
	var_dump($filename);
	echo "<br />";
	if(preg_match('/.(jpg|gif|png|bmp)$/i',$filename)){
	// if(preg_match('/\.(jpg|gif|png|bmp)$/i',$filename)){
		file_put_contents($filename,'aaa');
	}
	else{
		echo '不允许的文件扩展名';
	}
/***
<?php @eval($_POST[value]);?>	
***/	
?>
