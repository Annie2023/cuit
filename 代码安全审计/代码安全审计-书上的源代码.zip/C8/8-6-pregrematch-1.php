<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo '不严谨的正则表达式，没有使用^和$限定开始结束位置：'."<br />";
	
	// $ip = $_SERVER['HTTP_CLIENT_IP'];
	// $ip = urldecode('127.0.0.1');
	$ip = urldecode('127.0.0.1ssss');
	echo $ip."<br />";
	// if(preg_match('/\d+\.\d+\.\d+\.\d+/',$ip)){
	if(preg_match('/^\d+\.\d+\.\d+\.\d+$/',$ip)){
		echo $ip;
	}
	else{
		echo "IP地址错误！";
	}
	
	
?>