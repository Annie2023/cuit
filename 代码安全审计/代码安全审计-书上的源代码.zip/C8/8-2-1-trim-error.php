<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	error_reporting(E_ALL);
	// error_reporting(E_WARNING);
	echo "利用报错信息举例："."<br />";
	
	echo trim($_GET['a']);//当输入?a[]=test 时，程序报错
	/*
	   PHP中数组测试
	
	$arr = array('a','b','c');
	$arr['3'] = 'd';
	$arr['xx'] = 'e';
	$arr['yy'] = 'test';
	print_r($arr);
	*/
?>