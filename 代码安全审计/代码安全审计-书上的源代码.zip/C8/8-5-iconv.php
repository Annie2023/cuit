<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	error_reporting(E_ALL);
	echo "iconv()函数用来FUZZ举例："."<br />";
	for($i=0;$i<1000;$i++){
		$a = '1 ' . chr($i) . ' 2';
		echo $i . ' -- ';
		echo iconv("UTF-8","gbk",$a);
		echo '<br />';
	}
	
?>