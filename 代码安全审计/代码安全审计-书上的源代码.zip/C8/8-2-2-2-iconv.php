<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "iconv()函数使用举例："."<br />";
	//chr() 函数从指定的 ASCII 值返回字符。
	/*
	ASCII码：
	数字 32–126 分配给了能在键盘上找到的字符，当您查看或打印文档时就会出现。注：十进制32代表空格 ，十进制数字 127 代表 DELETE 命令。
	ASCII 表上的数字 0–31 分配给了控制字符，用于控制像打印机等一些外围设备
	扩展的 ASCII 包含 ASCII 中已有的 128 个字符，又增加了 128 个字符，总共是 256 个。
	*/
	$a = '1' . chr(130) . '2';//如果是chr(256)？
	echo $a;
	echo '<br />';
	echo iconv("UTF-8","gbk",$a);
	
?>