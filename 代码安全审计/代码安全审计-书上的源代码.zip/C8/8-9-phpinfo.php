<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	error_reporting(E_ALL);
	echo "PHP可变变量-phpinfo的用法举例："."<br />";
	//以下八条语句，都可以执行phpinfo
	$a = "${@phpinfo()}";
	// $a = "${ phpinfo()}";//大括号内第一个字符为空格
	// $a = "${	phpinfo()}";//大括号内第一个字符为TAB
	// $a = "${/**/phpinfo()}";//大括号内第一个字符为注释符
	// $a = "${
		// phpinfo()}";//大括号内第一个字符为回车换行符
	// $a = "${+phpinfo()}";
	// $a = "${-phpinfo()}";
	// $a = "${!phpinfo()}";
	
?>