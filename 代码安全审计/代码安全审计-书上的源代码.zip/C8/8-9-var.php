<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	error_reporting(E_ALL);
	echo "PHP可变变量举例："."<br />";
	
	$a = 'seay';
	$$a = '123';
	echo $seay;
	
?>