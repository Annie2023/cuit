<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo '不受GPC保护的$_SERVER和$_FILES：'."<br />";
	
	echo 'GPC目前的值为 '.get_magic_quotes_gpc();
	echo '<br />client-ip= ' . $_SERVER["HTTP_CLIENT_IP"];//获取客户端的IP
	echo '<br />$_GET[a]= ' . $_GET[a];
	/***
	在 PHP 中，$_SERVER是一个预定义的超全局变量，用于存储与当前脚本相关的服务器和请求信息。
    这个变量是一个关联数组，其中每个键对应着一个服务器或请求信息的属性，
	例如当前脚本的路径、请求的方法、服务器端口等等。

    $_SERVER 变量是在 PHP 启动时自动创建的，其中包含了与当前请求相关的信息。
	这些信息是由 Web 服务器收集并在请求到达 PHP 解释器之前作为环境变量传递给 PHP 的。
	PHP 解释器会将这些环境变量存储在 $_SERVER 变量中，使得开发者可以轻松地访问它们。

	***/
	
?>