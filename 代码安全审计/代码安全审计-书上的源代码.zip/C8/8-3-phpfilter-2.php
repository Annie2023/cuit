<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "php://filter使用举例2："."<br />";
	//输入?f=php://filter/convert.base64-encode/resource=1.php
	include($_GET['f']);
?>