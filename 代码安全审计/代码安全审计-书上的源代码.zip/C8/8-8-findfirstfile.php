<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	
	echo "Windows FindFirstFile函数利用举例："."<br />";
	include($_GET['file']);
	
?>