<?php
	$uid = $_GET['id'];
	$sql = "SELECT * FROM userinfo where id=$uid";
	$conn = mysql_connect('localhost','root','root');
	mysql_select_db("test",$conn);
	$result = mysql_query($sql,$conn);
	print_r('��ǰSQL��䣺' . $sql . '<br />�����');
	print_r(mysql_fetch_row($result));
	mysql_close();
?>