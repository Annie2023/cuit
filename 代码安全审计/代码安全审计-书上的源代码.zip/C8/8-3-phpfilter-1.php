<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "php://filter使用举例："."<br />";
	//ROT13是一种简易的替换式密码。
	file_put_contents("php://filter/write=string.rot13/resource=example.txt","Hello world");
	
?>