<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<?php
    echo "mb_convert_encoding函数使用举例："."<br />";
	
	$sql = "where id = '" . urldecode("-1%df%5c' -- ") . "'";
	print_r(mb_convert_encoding($sql,"UTF-8","GBK"));
	echo '<br />';
	print_r($sql);
?>