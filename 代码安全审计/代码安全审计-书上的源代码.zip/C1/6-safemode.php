<?php
	echo `whoami`;
?>