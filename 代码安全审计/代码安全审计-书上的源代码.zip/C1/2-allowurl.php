<?php
	echo "allow_url_include����"."</br>";
	include $_GET['a'];
	//include $_POST['a'];
	//include phpinfo();
?>