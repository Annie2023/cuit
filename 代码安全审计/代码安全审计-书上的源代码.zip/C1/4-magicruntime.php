<?php
	echo "magic_quotes_runtime����"."</br>";
	ini_set("magic_quotes_runtime","1");
	echo file_get_contents("test.txt");
?>