<?php
	echo "magic_quotes_gpc����"."</br>";
	echo $_GET['a'];
	echo "</br>";
	echo $_POST['b'];
?>