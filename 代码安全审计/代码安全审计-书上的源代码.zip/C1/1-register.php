<?php
	echo "register_globals����"."</br>";
	if($user=='admin'){
		echo 'ture';
		//do something
	}
?>