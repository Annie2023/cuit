<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "PHP使用MD5和sha1加密算法举例："."<br />";
	
	echo 'phpsec md5: '.md5('phpsec');
	echo '<br /> ';
	echo 'phpsec sha1: '.sha1('phpsec');

?>