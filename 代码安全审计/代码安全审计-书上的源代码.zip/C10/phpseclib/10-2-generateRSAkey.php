<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "PHP生成RSA密钥："."<br />";
	set_time_limit(0);
	include("./Crypt/RSA.php");
	$rsa = new Crypt_RSA();
	extract($rsa->createKey());
	echo "$privatekey" . '<br />' . "$publickey";

?>