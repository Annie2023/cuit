<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "PHP RSA加解密示例："."<br />";
	set_time_limit(0);// set_time_limit 来设置一个脚本的执行时间为无限长

	$PUBLIC_KEY = '-----BEGIN PUBLIC KEY----- MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCG2OewYkM9hQOJdthogOoj+8HO rJiZ+HXw8C3wbeu4cDcz0P/XgqneyfXpEFadEanRlCRySzAlz0ki7xI0lhFzqw1K OmsUTaOCrtGMsDFQ72io6Ln98hbqFnS3Pc8S0DhYAHrdvFmUyh/QcRJrWRbcQsV4 sG1ThpqjzwTgJLhYjwIDAQAB -----END PUBLIC KEY-----';
	$PRIVATE_KEY = '-----BEGIN RSA PRIVATE KEY----- MIICWwIBAAKBgQCG2OewYkM9hQOJdthogOoj+8HOrJiZ+HXw8C3wbeu4cDcz0P/X gqneyfXpEFadEanRlCRySzAlz0ki7xI0lhFzqw1KOmsUTaOCrtGMsDFQ72io6Ln9 8hbqFnS3Pc8S0DhYAHrdvFmUyh/QcRJrWRbcQsV4sG1ThpqjzwTgJLhYjwIDAQAB AoGAFW+oDnvjE4Wwb8BNm6ND//oMBPZJVfn6NGsslQgW951txmtxgvQPBqRqq/pA bTylwclqgnlzCyJTY93HB5wEOaDjJBSa/niHyRVnPQM51eIlNAmE18Lq77V/2QXh eL/fjmLc8MSjvfdbHJd/de4UewXE0N9fhc/TFXhqqtO1+X0CQQCKsYYmdDj2mkpy VZs/1Zn4xysocjw3OBp7dDG4Zihzik07qdLDmx9skFyxsMVw6igIPuIPvrbf1fLf SotKaHfDAkEA+OaXytfOwAYUbOqwbeJfigXDSjAgpqzU4LqmM3PeFGFSCgRShlJy lhypxYPb2tJaR3JWUzhPuyl0oJ4Wbe+bRQJASGMBLj7IoETFCEmP3tBALWzeJJ0C uptIjxiE/sYq5KrRRouLGlZzHzl1d7RYSGed/ze6yxbx4X+L5GjGrE47+wJAVeKL wiyRZOU0KxkYY/JW8TNn3bOZsKm2kw0UyHBU00d5nYc8SqksbOvbERKczHcFO94S N4kYygZV/g5OwwSI2QJAdGV4N43bK6DwWcpvAVD/KTlprvGUdHHol5Pe8CtipMr9 oE9qljXzppyzS9vVrf+6KtTDgIIivosxnrHHPyIOmQ== -----END RSA PRIVATE KEY-----';
	
	include('./Crypt/RSA.php');
	$rsa = new Crypt_RSA();
	$rsa->loadKey($PUBLIC_KEY) ; // 载入公钥
	$plaintext = 'phpsec';
	$rsa->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);
	$ciphertext = $rsa->encrypt($plaintext);
	$rsa->loadKey($PRIVATE_KEY) ; // 载入私钥 
	echo $ciphertext."<br /> "."<br />"."<br /> "; 
	echo $rsa->decrypt($ciphertext);

?>