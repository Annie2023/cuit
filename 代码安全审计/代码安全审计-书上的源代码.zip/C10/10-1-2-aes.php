<?php
    header("Content-Type:text/html;charset=utf-8");//PHP显示中文
	echo "PHP使用AES加密算法举例："."<br />";
	
	class Aes{
		public $_secrect_key='123456789';//密钥
		function Aes($key){
			$this->_secrect_key = $key;
		}
		/**
		* 加密方法
		* @param string $str
		* return string
		*/
		function encrypt($str){
		//AES, 128 ECB 模式加密数据
			$screct_key = $this->_secrect_key;
			$screct_key = base64_decode($screct_key);
			$str = trim($str);
			$str = $this->addPKCS7Padding($str);
			$iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128,MCRYPT_MODE_ECB),MCRYPT_RAND);
			$encrypt_str =	mcrypt_encrypt(MCRYPT_RIJNDAEL_128,$screct_key,$str,MCRYPT_MODE_ECB, $iv);
			return base64_encode($encrypt_str);
		}
		/**解密方法
		* @param string $str
		* @return string
		*/
		function decrypt($str){
		//AES, 128 ECB 模式加密数据
			$screct_key = $this->_secrect_key;
			$str = base64_decode($str);
			$screct_key = base64_decode($screct_key);
			$iv = mcrypt_create_iv (mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_ECB),MCRYPT_RAND);
			$encrypt_str =	mcrypt_decrypt(MCRYPT_RIJNDAEL_128,$screct_key,$str, MCRYPT_MODE_ECB,$iv);
			$encrypt_str = trim($encrypt_str);
			$encrypt_str = $this->stripPKSC7Padding($encrypt_str);
			return $encrypt_str;
		}
		/**填充算法
		* @param string $source
		* @return string
		*/
		function addPKCS7Padding($source){
			$source = trim($source);
			$block = mcrypt_get_block_size('rijndael-128', 'ecb'); 
			$pad = $block - (strlen($source) % $block);
			if ($pad <= $block){
				$char = chr($pad);
				$source .= str_repeat($char,$pad);
			}
			return $source;
			
		}
		/**移去填充算法
		* Qparam string $source
		* return string
		*/
		function stripPKSC7Padding($source){
			$source = trim($source);
			$char = substr($source,-1);
			$num = ord($char);
			if($num==62) return $source;
			$source = substr($source,0,-$num); 
			return $source;
		}
	}
//这个加密类使用起来也相当简单:
	$rep=new Aes('123456789');
	$input="hello aes";
	echo "原文：" . $input. "<br />";
	$encrypt_card=$rep->encrypt($input);
	echo "加密：" . $encrypt_card. "<br />";
	echo "解密：" . $rep->decrypt($rep->encrypt($input));

?>