function yhat=volum(beta,x)
     yhat=beta(1)*exp(beta(2)./x);
