<?php

if(phpversion() >= '5.3') {
	include 'zendcheck53.php';
} else {
	include 'zendcheck52.php';
}

?>