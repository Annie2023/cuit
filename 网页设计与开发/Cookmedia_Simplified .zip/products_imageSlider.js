let box=document.getElementById("box");
let innerBox=box.children[0];
let SliderUL=innerBox.children[0];
let imgArray=SliderUL.children;
let numberBar=innerBox.children[1];
let imgWidth=innerBox.offsetWidth;
let LRbutton=document.getElementById("LRbutton");
let leftButton=document.getElementById("leftButton");
let rightButton=document.getElementById("rightButton");
let pic=0;

for(let i=0;i<imgArray.length;i++){
    let NubmerLi=document.createElement("li");
    numberBar.appendChild(NubmerLi);
    NubmerLi.innerText=(i+1);
    NubmerLi.setAttribute("index",i);
    NubmerLi.onmouseover=function () {
        //先清除所有按钮的样式
        for (let j=0;j<numberBar.children.length;j++){
            numberBar.children[j].removeAttribute("class");//移除li元素的class属性
        }
        this.className="NubmerButtonCurrent";//设置li的新类名
        pic=this.getAttribute("index");
        animate(SliderUL,-pic*imgWidth);
    }
}
numberBar.children[0].className = "NubmerButtonCurrent";
SliderUL.appendChild(SliderUL.children[0].cloneNode(true));

box.onmouseover=function () {
    LRbutton.style.display="block";
    clearInterval(timeId);
};
box.onmouseout=function () {
    LRbutton.style.display="none";
    timeId=setInterval(SliderAnimation,3000);
};

leftButton.onclick=function () {
    if (pic==0){
        pic=imgArray.length-1;
        SliderUL.style.left=-pic*imgWidth+"px";
    }
    pic--;
    animate(SliderUL,-pic*imgWidth);
    for (let i = 0; i < numberBar.children.length; i++) {
        numberBar.children[i].removeAttribute("class");
    }
    numberBar.children[pic].className = "NubmerButtonCurrent";
};
rightButton.onclick=SliderAnimation;
function SliderAnimation() {
    if (pic == imgArray.length - 1) {
        pic = 0;
        SliderUL.style.left = 0 + "px";
    }
    pic++;
    animate(SliderUL, -pic * imgWidth);
    if (pic == imgArray.length - 1) {
        console.log("图片数组长度"+numberBar.children.length);
        numberBar.children[numberBar.children.length - 1].className = "";
        numberBar.children[0].className = "NubmerButtonCurrent";
    } else {
        for (let i = 0; i < numberBar.children.length; i++) {
            numberBar.children[i].removeAttribute("class");
        }
        numberBar.children[pic].className = "NubmerButtonCurrent";
    }
}
function animate(element, target) {
    clearInterval(element.timeId);
    //定时器的id值存储到对象的一个属性中
    element.timeId = setInterval(function () {
         let current = element.offsetLeft;
        //每次移动的距离
        let step = 10;
        step = current < target ? step : -step;//
        //当前移动到位置
        current += step;
        if (Math.abs(current - target) > Math.abs(step)) {
            element.style.left = current + "px";
        } else {
            //清理定时器
            clearInterval(element.timeId);
            //直接到达目标
            element.style.left = target + "px";
        }
    },10);
}