#include <Windows.h>
#include <process.h>
#include <stdio.h>

#define num 4
int flag = 0;
char FileName[4][6] = { "A.txt","B.txt","C.txt","D.txt" };
HANDLE			  g_hThreadParameter1, g_hThreadParameter2,g_hThreadParameter3,g_hThreadParameter4;	//�ź�����ؼ���
HANDLE			  g_hMain;
CRITICAL_SECTION  g_csThreadCode;

HANDLE hFileA;
HANDLE hFileB;
HANDLE hFileC;
HANDLE hFileD;

DWORD WINAPI Thread1(LPVOID);
DWORD WINAPI Thread2(LPVOID);
DWORD WINAPI Thread3(LPVOID);
DWORD WINAPI Thread4(LPVOID);

int main(int argc, char *argv)
{
	DWORD dwThreadID;
	HANDLE h[4]; 
	
	hFileA = CreateFile(TEXT("A.txt"), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);	//���� A B C D��4���ļ�
	hFileB = CreateFile(TEXT("B.txt"), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	hFileC = CreateFile(TEXT("C.txt"), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	hFileD = CreateFile(TEXT("D.txt"), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	CloseHandle(hFileA);
	CloseHandle(hFileB);
	CloseHandle(hFileC);
	CloseHandle(hFileD);

	printf("%s\n", FileName[0]);
	printf("%s\n", FileName[1]);
	printf("%s\n", FileName[2]);
	printf("%s\n", FileName[3]);

	g_hMain = CreateSemaphore(NULL, 0, 1, NULL);	//��ʼ���ź����͹ؼ���
	g_hThreadParameter1 = CreateSemaphore(NULL, 0, 1, NULL);	//��ǰ1����Դ���������1��ͬʱ����
	g_hThreadParameter2 = CreateSemaphore(NULL, 0, 1, NULL);	//��ǰ0����Դ���������1��ͬʱ����
	g_hThreadParameter3 = CreateSemaphore(NULL, 0, 1, NULL);	//��ǰ0����Դ���������1��ͬʱ����
	g_hThreadParameter4 = CreateSemaphore(NULL, 0, 1, NULL);	//��ǰ0����Դ���������1��ͬʱ����
	InitializeCriticalSection(&g_csThreadCode);

	h[0] = CreateThread(NULL, NULL, Thread1, NULL, 0, &dwThreadID);
	h[1] = CreateThread(NULL, NULL, Thread2, NULL, 0, &dwThreadID);
	h[2] = CreateThread(NULL, NULL, Thread3, NULL, 0, &dwThreadID);
	h[3] = CreateThread(NULL, NULL, Thread4, NULL, 0, &dwThreadID);
	ReleaseSemaphore(g_hMain, 1, NULL);	//�ź���++

	WaitForMultipleObjects(4, h, TRUE, INFINITE);	//�ȴ��߳̽���
	DeleteCriticalSection(&g_csThreadCode);	//�����ź����͹ؼ���
	
	CloseHandle(g_hThreadParameter1);
	CloseHandle(g_hThreadParameter2);
	CloseHandle(g_hThreadParameter3);
	CloseHandle(g_hThreadParameter4);

	CloseHandle(h[0]);
	CloseHandle(h[1]);
	CloseHandle(h[2]);
	CloseHandle(h[3]);

	return 0;
}


DWORD WINAPI Thread1(LPVOID)
{
	int i, j;
	FILE *stream;
	int k = 0;
	for (i = 1, j = 0; k < 8 ; k++,j--)
	{
		if (j < 0) j = 3;
		if (flag == 0)
		{
			WaitForSingleObject(g_hMain, INFINITE);	//�ȴ��ź���>0
			flag++;
		}
		else
		{
			WaitForSingleObject(g_hThreadParameter1, INFINITE);	//�ȴ��ź���>0
		}
		stream = fopen(FileName[j], "at+");
		int  ac = GetLastError();
		fprintf(stream, "%s", "1");
		fclose(stream);

		ReleaseSemaphore(g_hThreadParameter2, 1, NULL);	//�ź���++
	}
	return 0;
}

DWORD WINAPI Thread2(LPVOID)
{

	int i, j;
	FILE *stream;
	int k = 0;
	for ( i = 2, j = 1; k < 8; k++, j-- )
	{
		if (j < 0) j = 3;
		WaitForSingleObject(g_hThreadParameter2, INFINITE);	//�ȴ��ź���>
		stream = fopen(FileName[j], "at+");
		int ac = GetLastError();
		fprintf(stream, "%s", "2");
		fclose(stream);

		ReleaseSemaphore(g_hThreadParameter3, 1, NULL);	//�ź���++
	}
	return 0;
}
DWORD WINAPI Thread3(LPVOID)
{
	int i, j;
	FILE *stream;
	int k = 0;
	for ( i = 3, j = 2; k < 8; k++, j--)
	{
		if (j < 0 ) j = 3;
		WaitForSingleObject(g_hThreadParameter3, INFINITE);	//�ȴ��ź���>0
		stream = fopen(FileName[j], "at+");
		int ac = GetLastError();
		fprintf(stream, "%s", "3");
		fclose(stream);

		ReleaseSemaphore(g_hThreadParameter4, 1, NULL);	//�ź���++
	}
	return 0;
}

DWORD WINAPI Thread4(LPVOID)
{
	int i, j;
	FILE *stream;
	int k = 0;
	for ( i = 4, j = 3; k < 8; k++, j--)
	{
		if (j < 0) j = 3;
		WaitForSingleObject(g_hThreadParameter4, INFINITE);	//�ȴ��ź���>0
		stream = fopen(FileName[j], "at+");
		int ac = GetLastError();
		fprintf(stream, "%s", "4");
		fclose(stream);

		ReleaseSemaphore(g_hThreadParameter1, 1, NULL);	//�ź���++
	}
	return 0;
}

