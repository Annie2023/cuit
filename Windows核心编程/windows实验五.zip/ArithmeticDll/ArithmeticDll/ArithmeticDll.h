#pragma once
#ifndef ArithmeticDll_H_
#define ArithmeticDll_H_
#ifdef MYLIBDLL
#define MYLIBDLL Arithmetic "C" _declspec(dllimport) 
#else
#define MYLIBDLL extern "C" _declspec(dllexport) 
#endif
MYLIBDLL int Add(int plus1, int plus2);
MYLIBDLL int Sub(int sub1, int sub2);
MYLIBDLL int Mul(int mul1, int mul2);
MYLIBDLL int Div(int div1, int div2);
//You can also write like this:
//extern "C" {
//_declspec(dllexport) int Add(int plus1, int plus2);
//};
#endif
