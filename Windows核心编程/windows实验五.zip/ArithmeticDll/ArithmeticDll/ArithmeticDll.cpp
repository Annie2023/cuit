// ArithmeticDll.cpp : ���� DLL Ӧ�ó���ĵ���������
//
#include "stdafx.h"
#include <iostream>
#include "ArithmeticDll.h"
using namespace std;
int Add(int plus1, int plus2)
{
	int add_result = plus1 + plus2;
	return add_result;
}
int Sub(int sub1, int sub2)
{
	int sub_result = sub1 - sub2;
	return sub_result;

}
int Mul(int mul1, int mul2)
{
	int mul_result = mul1*mul2;
	return mul_result;

}
int Div(int div1, int div2)
{
	if (div2 != 0)
	{
		int div_result = div1 / div2;
		return div_result;
	}
}

